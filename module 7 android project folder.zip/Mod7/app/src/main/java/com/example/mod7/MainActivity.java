/*
Andrew Terrado
CST338
Module 7

This program takes user input (class number) and returns name/description.
Classes returned are mandatory CST classes.
String resources for class listings are stored in the strings.xml
 */

package com.example.mod7;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {

    EditText userInfo;
    Button btnClassFind;
    TextView tvClassResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userInfo = findViewById(R.id.userInfo);
        btnClassFind = findViewById(R.id.btnClassFind);
        tvClassResult = findViewById(R.id.tvClassResult);

        tvClassResult.setVisibility(View.GONE);

        btnClassFind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (userInfo.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Please enter number", Toast.LENGTH_SHORT).show();
                }

                else {
                    tvClassResult.setVisibility(View.VISIBLE);
                    int classNum = Integer.parseInt(userInfo.getText().toString());

                    if (classNum == 237){
                        tvClassResult.setText(getString(R.string.cst237));
                    }

                    else if (classNum == 300){
                        tvClassResult.setText(getString(R.string.cst300));
                    }

                    else if (classNum == 338){
                        tvClassResult.setText(getString(R.string.cst338));
                    }

                    else if (classNum == 311){
                        tvClassResult.setText(getString(R.string.cst311));
                    }

                    else if (classNum == 334){
                        tvClassResult.setText(getString(R.string.cst334));
                    }

                    else if (classNum == 336){
                        tvClassResult.setText(getString(R.string.cst336));
                    }

                    else if (classNum == 363){
                        tvClassResult.setText(getString(R.string.cst363));
                    }

                    else if (classNum == 370){
                        tvClassResult.setText(getString(R.string.cst370));
                    }

                    else if (classNum == 383){
                        tvClassResult.setText(getString(R.string.cst383));
                    }

                    else if (classNum == 325){
                        tvClassResult.setText(getString(R.string.cst325));
                    }

                    else if (classNum == 438){
                        tvClassResult.setText(getString(R.string.cst438));
                    }

                    else if (classNum == 462){
                        tvClassResult.setText(getString(R.string.cst462));
                    }

                    else if (classNum == 499){
                        tvClassResult.setText(getString(R.string.cst499));
                    }

                    else{
                        tvClassResult.setVisibility(View.GONE);
                        Toast.makeText(MainActivity.this, "Please enter a valid class number.", Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });

    }
}
