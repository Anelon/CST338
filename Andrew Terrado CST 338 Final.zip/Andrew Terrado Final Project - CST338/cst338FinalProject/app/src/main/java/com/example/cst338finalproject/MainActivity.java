/*
Andrew Terrado
CST 338 - Software Design

This program is designed to take patient data (with character/range validation).
After clicking the button, the data is then processed to produce a concatenated
string summary. After, further evaluation is done to create a string of possible
health concerns. Both strings are returned to the user.

In addition to increasing the complexity over the previous Android app, this
program introduces two new elements, the check box and the toggle button.
The check box is utilized at the start to record disclaimer acknowledgement.
Leaving the check box unchecked will prevent the user from advancing.
The toggle button is used when select the patient's arm for the BP reading.

With the exception of button hints, most final strings are stored in the strings.xml

 */


package com.example.cst338finalproject;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.widget.CheckBox;
import android.widget.ToggleButton;


public class MainActivity extends AppCompatActivity {

   CheckBox disclaimer;
   EditText systolic;
   EditText diastolic;
   ToggleButton armToggle;
   EditText hr;
   EditText rr;
   EditText o2;
   Button btnProcess;
   TextView result;



   @Override
   protected void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.activity_main);

      //Initialize variables
      systolic = findViewById(R.id.systolic);
      diastolic =findViewById(R.id.diastolic);
      hr = findViewById(R.id.hr);
      rr = findViewById(R.id.rr);
      o2 = findViewById(R.id.o2);
      btnProcess =findViewById(R.id.btnProcess);
      result = findViewById(R.id.result);
      armToggle = findViewById(R.id.armToggle);
      disclaimer = findViewById(R.id.disclaimer);
      result.setVisibility(View.GONE);


      //Main button
      btnProcess.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
            result.setText ("" ); //Resets results if text is re-entered after result

            //Determines if warning was acknowledged via check box, returns to user if not
            if (!disclaimer.isChecked()){
               Toast.makeText(MainActivity.this, "Please acknowledge the " +
                       "warning.", Toast.LENGTH_SHORT).show();
               return;
            }

            //Initializes strings
            String arm = "";

            //Retrieves result of arm toggle, left or right arm
            if (armToggle.isChecked()){
               arm = "Left";
            }
            else{
               arm = "Right";}


            //Initialzes integers from user information
            int systolicBP;
            int diastolicBP;
            int pulse;
            int breaths;
            int oxygen;


            //Checks to determine validity of text input from user.
            //If not in range, prompts user to check entry and returns to user.
            //Sets variable after if statement in case text box is empty (prevents error)

           if (systolic.getText().toString().isEmpty() ||
                    Integer.parseInt(systolic.getText().toString()) < 30
                    || Integer.parseInt(systolic.getText().toString()) > 370){
               Toast.makeText(MainActivity.this, "Please " +
                       "check systolic BP entry", Toast.LENGTH_SHORT).show();
               return;
            }
           else {
              systolicBP = Integer.parseInt(systolic.getText().toString());
           }

            if (diastolic.getText().toString().isEmpty() ||
                    Integer.parseInt(diastolic.getText().toString()) < 20
                    || Integer.parseInt(diastolic.getText().toString()) > 370){
               Toast.makeText(MainActivity.this, "Please check" +
                       " diastolic BP entry", Toast.LENGTH_SHORT).show();
               return;
            }
            else{
               diastolicBP =Integer.parseInt(diastolic.getText().toString());
            }

            if (hr.getText().toString().isEmpty() ||
                    Integer.parseInt(hr.getText().toString()) < 25
                    || Integer.parseInt(hr.getText().toString()) > 200){
               Toast.makeText(MainActivity.this, "Please check" +
                       " heart rate entry", Toast.LENGTH_SHORT).show();
               return;
            }
            else {
               pulse = Integer.parseInt(hr.getText().toString());
            }

            if (rr.getText().toString().isEmpty() ||
                    Integer.parseInt(rr.getText().toString()) < 7
                    || Integer.parseInt(rr.getText().toString()) > 60){
               Toast.makeText(MainActivity.this, "Please check " +
                       "breath rate entry", Toast.LENGTH_SHORT).show();
               return;
            }
            else {
               breaths = Integer.parseInt(rr.getText().toString());
            }

            if (o2.getText().toString().isEmpty() ||
                    Integer.parseInt(o2.getText().toString()) < 60
                    || Integer.parseInt(o2.getText().toString()) > 100){
               Toast.makeText(MainActivity.this, "Please check" +
                       " o2 saturation entry", Toast.LENGTH_SHORT).show();
               return;
            }

            else {
               oxygen = Integer.parseInt(o2.getText().toString());

               //Sends valid integers and string to the infoProcessosr
               infoProcessor(systolicBP, diastolicBP, arm, pulse, breaths, oxygen);
            }
         }
      });

   }

   //Evaluates patient data, creates string of vital signs summary and possible health concerns
   private void infoProcessor (int systolic, int diastolic, String arm, int pulse, int breaths, int o2){
      result.setVisibility(View.VISIBLE);

      boolean interventionNeeded = false;
      String summary = "";
      String evaluation ="";

      //Generates initial patient summary string
      summary = "Patient Status Summary\n" +
              "BP: " + systolic + "/" +
              diastolic + ", Arm:" + arm + ", Heart Rate: " +
           breaths + ", Breath Rate: " + rr.getText().toString() +
              ", O2: " +o2+ "%\n" + "\nEvaluation\n";

      //Evaluates patient data, creates string of possible health concerns
      //If health concern is detected, boolean to add intervention is triggered.
      //Adds string of alert to evaluation string
      //Alerts are stored in the string xml

      if (systolic >  170)
      {
         evaluation = (evaluation + getString(R.string.hypertensionS));
         interventionNeeded = true;
      }

      if (diastolic >  90)
      {
         evaluation = (evaluation + getString(R.string.hypertensionD));
         interventionNeeded = true;
      }

      if (systolic<  90)
      {
         evaluation = (evaluation + getString(R.string.hypotensionS));
         interventionNeeded = true;
      }
      if (diastolic <  60)
      {
         evaluation = (evaluation + getString(R.string.hypotensionD));
         interventionNeeded = true;
      }

      if (pulse >  100 )
      {
         evaluation = (evaluation + getString(R.string.tachycardia));
         interventionNeeded = true;
      }

      if (pulse <  60 )
      {
         evaluation = (evaluation + getString(R.string.bradycardia));
         interventionNeeded = true;
      }

      if (breaths >  20 )
      {
         evaluation = (evaluation + getString(R.string.tachypnea));
         interventionNeeded = true;
      }

      if (breaths <  12 )
      {
         evaluation = (evaluation + getString(R.string.bradypnea));
         interventionNeeded = true;
      }

      if (o2 <  95 )
      {
         evaluation = (evaluation + getString(R.string.hypoxia));
         interventionNeeded = true;
      }

      if (interventionNeeded == true) {
         evaluation = (evaluation + getString(R.string.intervention));
      }

      evaluation = (evaluation +getString (R.string.clear));


      //Sets the text box to include summary and evaluation
      displayResult (summary, evaluation);
   }


   private void displayResult(String finalSummary, String finalEvaluation)
   {
      result.setText (finalSummary + finalEvaluation );

   }

}
